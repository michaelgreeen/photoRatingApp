export interface IPhoto {
    id: number;
    url: string;
    score: number;
}
